/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author nataliaislas
 */
public class PilaA <T> implements PilaADT<T>{
    private int tope;
    private T[]datos;
    private final int MAX=20;

    public PilaA() {
        datos=(T[]) new Object[MAX];
        tope=-1; //PARA INDICAR QUE LA PILA ESTA VACIA
    }
    
    public PilaA(int MAX) {
        datos=(T[]) new Object[MAX];
        tope=-1; 
    }

    public int getTope() {
        return tope;
    }
    
    

    public void push(T datoNuevo) {
        if(tope == datos.length-1) //no hay espacio en la pila 
            expande();
        tope++;
        datos[tope]=datoNuevo;
           
    }
    
    private void expande(){
        T[]masGrande =(T[])new Object[datos.length*2];
        
        for(int i=0; i<=tope; i++)
            masGrande[i]=datos[i];
        datos=masGrande;
    }

    public T pop() {
        if(this.isEmpty())
            throw new ExcepcionColeccionVacia("Error: la pila esta vacía");
        T resultado=datos[tope];
        datos[tope]=null;
        tope--;
        return resultado;
    }

    public boolean isEmpty() {
        return tope ==-1;
    }

    public T peek() {
        if(this.isEmpty())
            throw new ExcepcionColeccionVacia("Error: la pila esta vacía");
        return datos[tope];
    }

   public void multiPop(int n){
       
        if(tope+1>=n){
            for(int i=0; i<n; i++){
               datos[tope]=null;
               tope--;
            }
        } 
        else{
            throw new ExcepcionColeccionVacia("Error: no hay ese numero de elemntos en la pila");         
        }
    }
   
   public String toString(){
       StringBuilder cad=new StringBuilder();
       PilaA<T> guarda=new PilaA();
       
       while(!isEmpty()){
           guarda.push(pop());
           cad.append(guarda.peek()+" ");
       }
       while(!guarda.isEmpty()){
           push(guarda.pop());
       }
       return cad.toString();
    }
}