/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

import java.util.ArrayList;

/**
 *
 * @author nataliaislas
 */
public class MetodosIniciales {
    
    public static int signoPrioridad(char operador){
        int nivel=0;
        
        switch(operador){
            case '$':
                nivel=1;
                break;
            case '/':
                nivel=2;
                break;
            case '*':
                nivel=2;
                break;
            case '+':
                nivel=3;
                break;
            case '-':
                nivel=3;
                break;
            case '(':
                nivel=4;
                break; 
                
        } return nivel;
    }
    
    public static int queSignoPrioridad(char car1, char car2){
        int fin1=signoPrioridad(car1);
        int fin2=signoPrioridad(car2);
        int resp;
        
        if(fin1<fin2)
            resp=1; //el primero es prioridad
        else if (fin1>fin2)
            resp=2; //el segundo es prioridad
        else
            resp=0;
        
        return resp;   
    }
    
    public static int signoONum(char car){
        int resp;
        
        if(car=='+' || car=='-' || car=='*' || car=='/' || car=='(' || car==')' || car=='$')
            resp=0;
        else
            resp=1; //numero
        
        return resp;
    }
    
    public static int signoONumNeg(char car){
        int resp;
        
        if(car=='+' || car=='-' || car=='*' || car=='/' || car=='(' || car==')' || car=='$')
            resp=0;
        else
            if(car == '_')
                resp=1; 
            else
                resp=0; //numero
        
        return resp;
    }
    
    
    
    
    public static void main(String[] args) {
        
        
        
    }
    
}
