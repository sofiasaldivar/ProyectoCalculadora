/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;

import interfacepila.RevisarParentesis;

/**
 *
 * @author nataliaislas
 */
public class Calculadora {
    
    public static int signoNumParentesis(char car){
        int resp;
        
        if(car=='+' || car=='-' || car=='*' || car=='/' || car=='$')
            resp=0;
        else if (car=='(')
            resp=2;
        else
            resp=1;
        
        return resp;
    }
    
    public static boolean sintaxis(String dato){
        boolean res=true;
        char car;
        int i=0, adentro=-1, afuera=-1; 
        PilaA<Character> pila=new PilaA <Character>();
        PilaA<Character> pila2=new PilaA <Character>();
        
        
        if(signoNumParentesis(dato.charAt(0)) == 0){ //SI HAY UN SIGNO AL PRINCIPIO
                res=false;
            }
        
        if(!RevisarParentesis.revisaCad(dato)){ //REVISAR QUE ESTEN BALANCEADOS LOS PARENTESIS 
            res=false;
        }
         
            i=0;
            while(dato.length()> i+1 && res){
                pila2.push(dato.charAt(i));
                car=dato.charAt(i+1);
                adentro=signoNumParentesis(pila2.peek());
                afuera=signoNumParentesis(car);
                if((adentro==2 || adentro==0) && afuera==0) //para ver si hay dos signos juntos o un ( y despues un signo
                    res=false;
                i++;
                pila2.pop();
            }
        
        return res;
    }

    
    public static void main(String[] args) {
        String a="12+_3.2";
        
        System.out.println(sintaxis(a));
    }
    
}
